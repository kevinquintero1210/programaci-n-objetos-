/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metro;

/**
 *
 * @author Kevin Sebastian
 */
public class metodo1 {

    public int metodo_validar(int dia) {

        if (dia >= 1 || dia <= 31) {

        }

        return dia;

    }

}
